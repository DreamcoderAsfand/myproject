<?php

$db_host = "localhost";
$db_name = "meport";
$db_pass = "";
$db_user = "root";



$con = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

?>